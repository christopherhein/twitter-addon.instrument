<?php
/**
* Orchestra Twitter-Addon
*
* Fired from thw CMD Line using 'php script/deploy'
* Variables may be passed in for db merging and db rebuilding on the live server
*
* Licensed under the MIT license.
*
* @category   Orchestra
* @copyright  Copyright (c) 2010, Christopher Hein
* @license    http://orchestramvc.chrishe.in/license
* @version    Release: 0.0.1:beta
* @link       http://orchestramvc.chrishe.in/
*
*/